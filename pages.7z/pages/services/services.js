Page({
  data: {
    services: [
      {
        id: 1,
        title: '整屋定制',
        icon: '🏠',
        color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        desc: '从设计到施工，全程一站式服务',
        features: ['免费上门量房', '3D效果图', '环保材料', '专业施工团队'],
        price: '800-1500元/㎡'
      },
      {
        id: 2,
        title: '局部改造',
        icon: '🔧',
        color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        desc: '厨卫改造、墙面翻新等局部装修',
        features: ['快速施工', '不影响居住', '专业防护', '质保3年'],
        price: '5000-30000元'
      },
      {
        id: 3,
        title: '软装设计',
        icon: '🎨',
        color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
        desc: '家具、窗帘、装饰品等软装搭配',
        features: ['风格定制', '色彩搭配', '采购指导', '摆场服务'],
        price: '200-500元/㎡'
      },
      {
        id: 4,
        title: '旧房翻新',
        icon: '♻️',
        color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
        desc: '老房改造，焕然一新',
        features: ['拆除保护', '水电改造', '防水处理', '整体翻新'],
        price: '600-1200元/㎡'
      },
      {
        id: 5,
        title: '商业空间',
        icon: '🏢',
        color: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
        desc: '办公室、店铺等商业空间设计',
        features: ['品牌定位', '功能规划', '快速交付', '售后保障'],
        price: '面议'
      },
      {
        id: 6,
        title: '验房监理',
        icon: '✅',
        color: 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
        desc: '专业验房、施工监理服务',
        features: ['第三方监督', '质量把控', '进度管理', '问题整改'],
        price: '3000-8000元'
      }
    ],
    guarantees: [
      { id: 1, icon: '🔒', title: '质量保障', desc: '5年质保\n终身维护' },
      { id: 2, icon: '💎', title: '环保材料', desc: 'E0级板材\n品牌辅材' },
      { id: 3, icon: '⏱️', title: '准时交付', desc: '工期承诺\n延期赔付' },
      { id: 4, icon: '💰', title: '透明报价', desc: '无增项\n无隐形消费' }
    ],
    standards: [
      { id: 1, number: '01', title: '水电工程', desc: '强弱电分管铺设，横平竖直，防水试压48小时，确保质量' },
      { id: 2, number: '02', title: '泥瓦工程', desc: '墙地砖铺贴平整，砖缝均匀，空鼓率≤5%' },
      { id: 3, number: '03', title: '木工工程', desc: '吊顶平整牢固，柜体结构稳定，接缝严密' },
      { id: 4, number: '04', title: '油漆工程', desc: '墙面平整光滑，无色差，漆面均匀无流坠' },
      { id: 5, number: '05', title: '安装工程', desc: '洁具、灯具、五金安装规范，功能正常' }
    ]
  },

  onLoad() {
    // 页面加载
  },

  goToServiceDetail(e) {
    const id = e.currentTarget.dataset.id;
    const service = this.data.services.find(s => s.id === id);
    wx.showModal({
      title: service.title,
      content: `服务详情：\n${service.desc}\n\n参考价格：${service.price}\n\n咨询电话：400-888-8888`,
      confirmText: '立即预约',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/booking/booking'
          });
        }
      }
    });
  },

  showConsultModal() {
    wx.showModal({
      title: '在线咨询',
      content: '请选择您的咨询方式',
      confirmText: '电话咨询',
      cancelText: '在线预约',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: '4008888888'
          });
        } else if (res.cancel) {
          wx.navigateTo({
            url: '/pages/booking/booking'
          });
        }
      }
    });
  }
})
