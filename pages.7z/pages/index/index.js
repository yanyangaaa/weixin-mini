Page({
  data: {
    banners: [
      { id: 1, image: '/images/banner/banner1.jpg' },
      { id: 2, image: '/images/banner/banner2.jpg' },
      { id: 3, image: '/images/banner/banner3.jpg' }
    ],
    quickNav: [
      { id: 1, title: '免费设计', icon: '✏️', color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', url: '/pages/booking/booking' },
      { id: 2, title: '案例展示', icon: '🏠', color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', url: '/pages/cases/cases' },
      { id: 3, title: '装修服务', icon: '🛠️', color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', url: '/pages/services/services' },
      { id: 4, title: '关于我们', icon: '📞', color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)', url: '/pages/about/about' }
    ],
    advantages: [
      { id: 1, icon: '👨‍🎨', title: '专业设计', desc: '10年经验设计师团队' },
      { id: 2, icon: '💰', title: '透明报价', desc: '无隐形消费，明码标价' },
      { id: 3, icon: '✅', title: '品质保障', desc: '质保5年，终身维护' },
      { id: 4, icon: '⏰', title: '准时交付', desc: '签约工期，延期赔付' }
    ],
    cases: [
      { id: 1, title: '现代简约风格', cover: '/images/cases/生成家居风格图片.png', style: '现代', area: '120' },
      { id: 2, title: '北欧清新风格', cover: '/images/cases/生成家居风格图片 (1).png', style: '北欧', area: '95' },
      { id: 3, title: '新中式风格', cover: '/images/cases/生成家居风格图片 (2).png', style: '中式', area: '150' },
      { id: 4, title: '轻奢风格', cover: '/images/cases/生成家居风格图片 (3).png', style: '轻奢', area: '180' }
    ],
    process: [
      { step: '01', title: '预约咨询', desc: '在线预约，专业顾问1对1服务' },
      { step: '02', title: '上门量房', desc: '设计师免费上门精准测量' },
      { step: '03', title: '方案设计', desc: '3天出设计方案和报价' },
      { step: '04', title: '签约施工', desc: '签订合同，进场施工' },
      { step: '05', title: '验收交付', desc: '严格验收，满意后交付' }
    ]
  },

  onLoad() {
    // 页面加载
  },

  navigateTo(e) {
    const url = e.currentTarget.dataset.url;
    if (url) {
      wx.navigateTo({ url });
    }
  },

  goToCaseDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/case-detail/case-detail?id=${id}`
    });
  }
})
