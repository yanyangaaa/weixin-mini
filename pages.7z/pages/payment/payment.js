Page({
  data: {
    amount: 0,
    type: '',  // deposit=定金, service=服务费
    name: '',
    phone: '',
    paymentMethod: 'wechat',  // wechat, alipay
    orderNo: '',
    countdown: 15 * 60,  // 15分钟倒计时
    timer: null
  },

  onLoad(options) {
    // 获取订单信息
    const { amount, type, name, phone } = options;
    const orderNo = this.generateOrderNo();

    this.setData({
      amount: amount || 500,
      type: type || 'deposit',
      name: name || '',
      phone: phone || '',
      orderNo
    });

    // 启动倒计时
    this.startCountdown();
  },

  onUnload() {
    // 页面卸载时清除定时器
    if (this.data.timer) {
      clearInterval(this.data.timer);
    }
  },

  // 生成订单号
  generateOrderNo() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    
    return `JY${year}${month}${day}${hours}${minutes}${seconds}${random}`;
  },

  // 开始倒计时
  startCountdown() {
    this.data.timer = setInterval(() => {
      let countdown = this.data.countdown - 1;
      
      if (countdown <= 0) {
        clearInterval(this.data.timer);
        this.handleTimeout();
        return;
      }

      this.setData({ countdown });
    }, 1000);
  },

  // 超时处理
  handleTimeout() {
    wx.showModal({
      title: '订单已超时',
      content: '订单已超过支付时间，请重新下单',
      showCancel: false,
      success: () => {
        wx.navigateBack();
      }
    });
  },

  // 选择支付方式
  selectPayment(e) {
    const method = e.currentTarget.dataset.method;
    this.setData({
      paymentMethod: method
    });
  },

  // 发起支付
  handlePay() {
    const { paymentMethod, amount, orderNo, name, phone, type } = this.data;

    // 仅支持微信支付
    if (paymentMethod !== 'wechat') {
      wx.showToast({
        title: '暂仅支持微信支付',
        icon: 'none'
      });
      return;
    }

    wx.showLoading({
      title: '处理中...'
    });

    // ====== 第一步：向后端请求获取微信支付参数 ======
    const app = getApp();
    const apiUrl = app.globalData.baseUrl + app.globalData.paymentApiPath;

    wx.request({
      url: apiUrl,  // 后端支付接口地址
      method: 'POST',
      data: {
        orderNo: orderNo,      // 订单号
        amount: amount,        // 支付金额（单位：元）
        type: type,            // 订单类型（deposit=定金, service=服务费）
        name: name,            // 客户姓名
        phone: phone,          // 客户手机号
        paymentMethod: paymentMethod  // 支付方式
      },
      header: {
        'content-type': 'application/json',
        // ====== 📌 配置项3：如果需要token认证，取消下面注释 ======
        // 'Authorization': 'Bearer ' + wx.getStorageSync('token')
      },
      success: (res) => {
        wx.hideLoading();
        
        console.log('后端返回数据：', res.data);

        // 检查后端返回是否成功
        if (res.statusCode === 200 && res.data.code === 0 && res.data.data) {
          // ====== 第二步：使用后端返回的参数调起微信支付 ======
          const paymentData = res.data.data;
          
          wx.requestPayment({
            timeStamp: paymentData.timeStamp,    // 时间戳（后端生成）
            nonceStr: paymentData.nonceStr,      // 随机字符串（后端生成）
            package: paymentData.package,        // 预支付交易会话标识（后端生成）
            signType: paymentData.signType || 'RSA',  // 签名方式（微信支付V3使用RSA）
            paySign: paymentData.paySign,        // 签名（后端生成）
            success: (payRes) => {
              console.log('✅ 微信支付成功', payRes);
              // 支付成功，显示成功页面
              this.showPaymentSuccess();
            },
            fail: (err) => {
              console.error('❌ 微信支付失败', err);
              
              // 判断是用户取消还是支付失败
              if (err.errMsg.indexOf('cancel') > -1) {
                wx.showToast({
                  title: '您已取消支付',
                  icon: 'none',
                  duration: 2000
                });
              } else {
                wx.showToast({
                  title: '支付失败：' + err.errMsg,
                  icon: 'none',
                  duration: 3000
                });
              }
            }
          });
          
        } else {
          // 后端返回错误
          const errorMsg = res.data.message || '获取支付参数失败';
          console.error('后端返回错误：', errorMsg);
          wx.showToast({
            title: errorMsg,
            icon: 'none',
            duration: 3000
          });
        }
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('❌ 网络请求失败', err);
        
        wx.showToast({
          title: '网络请求失败，请检查网络连接',
          icon: 'none',
          duration: 3000
        });
      }
    });
  },

  // 支付成功
  showPaymentSuccess() {
    // 清除定时器
    if (this.data.timer) {
      clearInterval(this.data.timer);
    }

    // 保存支付记录
    const paymentRecord = {
      orderNo: this.data.orderNo,
      amount: this.data.amount,
      type: this.data.type,
      paymentMethod: this.data.paymentMethod,
      status: 'success',
      name: this.data.name,
      phone: this.data.phone,
      createTime: new Date().toLocaleString()
    };

    let paymentList = wx.getStorageSync('paymentList') || [];
    paymentList.unshift(paymentRecord);
    wx.setStorageSync('paymentList', paymentList);

    // 显示成功提示
    wx.showModal({
      title: '支付成功',
      content: '感谢您的信任！我们的设计师将优先为您服务，请保持手机畅通。',
      showCancel: false,
      confirmText: '完成',
      success: () => {
        // 返回首页
        wx.switchTab({
          url: '/pages/index/index'
        });
      }
    });
  },

  // 格式化倒计时
  formatCountdown(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
})
