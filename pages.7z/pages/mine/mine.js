Page({
  data: {
    userInfo: {},
    defaultAvatar: 'https://via.placeholder.com/200x200/E5E5E5/999?text=未登录',
    menuList: [
      { id: 1, icon: '📋', title: '我的订单', action: 'orders', desc: '' },
      { id: 2, icon: '📞', title: '客服电话', action: 'phone', desc: '400-888-8888' },
      { id: 3, icon: '🏢', title: '关于我们', action: 'about', desc: '' },
      { id: 4, icon: '⚙️', title: '设置', action: 'settings', desc: '' }
    ]
  },

  onLoad() {
    this.loadUserInfo();
  },

  onShow() {
    // 页面显示时刷新数据
  },

  loadUserInfo() {
    // 尝试从缓存加载用户信息
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({ userInfo });
    }
  },

  login() {
    if (this.data.userInfo.nickname) {
      wx.showToast({
        title: '已登录',
        icon: 'success'
      });
      return;
    }

    // 模拟登录
    wx.showModal({
      title: '登录提示',
      content: '是否授权登录?',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '登录中...' });
          
          // 模拟登录成功
          setTimeout(() => {
            wx.hideLoading();
            const userInfo = {
              nickname: '装修达人',
              phone: '138****8888',
              avatar: 'https://via.placeholder.com/200x200/4ECDC4/fff?text=用户'
            };
            this.setData({ userInfo });
            wx.setStorageSync('userInfo', userInfo);
            wx.showToast({ title: '登录成功', icon: 'success' });
          }, 1000);

          // 实际开发中使用微信登录
          // wx.getUserProfile({
          //   desc: '用于完善用户资料',
          //   success: (res) => {
          //     // 处理登录逻辑
          //   }
          // });
        }
      }
    });
  },

  handleMenuClick(e) {
    const action = e.currentTarget.dataset.action;

    switch(action) {
      case 'orders':
        wx.navigateTo({ url: '/pages/orders/orders' });
        break;
      case 'phone':
        wx.makePhoneCall({
          phoneNumber: '4008888888'
        });
        break;
      case 'about':
        wx.navigateTo({ url: '/pages/about/about' });
        break;
      case 'settings':
        this.showSettings();
        break;
    }
  },

  showSettings() {
    const items = ['清除缓存', '退出登录'];
    wx.showActionSheet({
      itemList: items,
      success: (res) => {
        switch(res.tapIndex) {
          case 0:
            wx.showModal({
              title: '清除缓存',
              content: '确定要清除缓存吗?',
              success: (modalRes) => {
                if (modalRes.confirm) {
                  wx.clearStorage();
                  wx.showToast({ title: '清除成功', icon: 'success' });
                }
              }
            });
            break;
          case 1:
            if (this.data.userInfo.nickname) {
              wx.showModal({
                title: '退出登录',
                content: '确定要退出登录吗?',
                success: (modalRes) => {
                  if (modalRes.confirm) {
                    this.setData({ userInfo: {} });
                    wx.removeStorageSync('userInfo');
                    wx.showToast({ title: '已退出登录', icon: 'success' });
                  }
                }
              });
            } else {
              wx.showToast({ title: '您还未登录', icon: 'none' });
            }
            break;
        }
      }
    });
  },

  contactService() {
    wx.showModal({
      title: '联系客服',
      content: '客服电话：400-888-8888\n工作时间：9:00-18:00',
      confirmText: '拨打电话',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: '4008888888'
          });
        }
      }
    });
  }
})
