Page({
  data: {
    caseDetail: {},
    isFavorite: false,
    casesData: {
      1: {
        id: 1,
        title: '现代简约三居室',
        cover: '/images/cases/生成家居风格图片.png',
        style: '现代简约',
        area: '120',
        layout: '三室两厅',
        budget: '15-20万',
        duration: '90天',
        desc: '这套现代简约风格的三居室，以简洁明快的设计为主调，注重空间的实用性与舒适度。',
        designDesc: '本案例采用现代简约风格设计，整体色调以白色、灰色为主，搭配木质家具，营造出简洁大方的居住氛围。客厅采用开放式设计，与餐厅相连，增加了空间的通透性。主卧设计注重私密性和舒适度，配备独立卫生间。儿童房采用活泼的色彩搭配，为孩子创造一个快乐的成长空间。厨房采用一字型布局，操作流畅便捷。整体设计强调功能性，同时又不失美感。',
        designer: '张设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/4ECDC4/fff?text=张',
        designerTitle: '高级室内设计师',
        designerExp: 10,
        designerWorks: 156
      },
      2: {
        id: 2,
        title: '北欧风清新小窝',
        cover: '/images/cases/生成家居风格图片 (1).png',
        style: '北欧',
        area: '95',
        layout: '两室一厅',
        budget: '10-15万',
        duration: '75天',
        desc: '北欧风格设计，简约、自然、人性化，浅色调为主，营造温馨舒适的家居氛围。',
        designDesc: '本案例采用北欧风格设计理念，以白色和原木色为主色调，搭配绿植和简约家具，营造清新自然的居住环境。客厅采用大面积落地窗，引入充足的自然光线。卧室设计温馨舒适，注重收纳功能。整体空间布局合理，动线流畅，充分利用每一寸空间。',
        designer: '李设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/A8E6CF/fff?text=李',
        designerTitle: '资深室内设计师',
        designerExp: 8,
        designerWorks: 98
      },
      3: {
        id: 3,
        title: '新中式大平层',
        cover: '/images/cases/生成家居风格图片 (2).png',
        style: '新中式',
        area: '150',
        layout: '四室两厅',
        budget: '25-30万',
        duration: '100天',
        desc: '传统中式风格与现代元素完美结合，既有古典韵味又不失现代气息。',
        designDesc: '本案例以新中式风格为主，融合传统文化元素与现代设计理念。采用对称式布局，注重空间层次感。运用木质格栅、中式屏风等传统元素，营造典雅大气的空间氛围。色彩以暖色调为主，搭配现代家具，呈现雅致舒适的居住环境。',
        designer: '王设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/FFD3B6/fff?text=王',
        designerTitle: '首席设计师',
        designerExp: 12,
        designerWorks: 203
      },
      4: {
        id: 4,
        title: '轻奢风雅居',
        cover: '/images/cases/生成家居风格图片 (3).png',
        style: '轻奢',
        area: '180',
        layout: '四室两厅',
        budget: '30-40万',
        duration: '110天',
        desc: '低调奢华，注重细节与品质，展现精致优雅的生活品味。',
        designDesc: '轻奢风格设计追求品质与细节的完美结合。采用高级灰、香槟金等优雅色调，搭配大理石、皮质等高品质材料。空间布局注重仪式感，灯光设计层次丰富。整体呈现低调奢华、精致优雅的居住氛围，满足现代都市精英的生活品味。',
        designer: '赵设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/DCEDC1/fff?text=赵',
        designerTitle: '资深设计总监',
        designerExp: 15,
        designerWorks: 267
      },
      5: {
        id: 5,
        title: '美式田园风格',
        cover: '/images/cases/生成家居风格图片 (4).png',
        style: '美式',
        area: '140',
        layout: '三室两厅',
        budget: '20-25万',
        duration: '95天',
        desc: '温馨舒适，注重实用性，营造休闲自在的居住环境。',
        designDesc: '美式田园风格强调舒适与自然。采用暖色调，大量运用木质元素和布艺软装。家具造型简洁实用，注重收纳功能。整体空间宽敞明亮，营造出温馨惬意、休闲自在的家居氛围，适合追求舒适生活的家庭。',
        designer: '刘设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/FFC8DD/fff?text=刘',
        designerTitle: '高级室内设计师',
        designerExp: 9,
        designerWorks: 134
      },
      6: {
        id: 6,
        title: '日式原木风',
        cover: '/images/cases/生成家居风格图片 (5).png',
        style: '日式',
        area: '85',
        layout: '两室一厅',
        budget: '8-12万',
        duration: '70天',
        desc: '追求简约、自然、禅意的设计理念，大量运用原木材质。',
        designDesc: '日式风格追求简约与自然的和谐统一。大量采用原木材质，色调以浅木色和白色为主。空间布局注重功能性和收纳性，运用推拉门、榻榻米等日式元素。整体呈现宁静、舒适、充满禅意的居住空间。',
        designer: '陈设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/CAFFBF/fff?text=陈',
        designerTitle: '室内设计师',
        designerExp: 7,
        designerWorks: 89
      },
      7: {
        id: 7,
        title: '现代简约公寓',
        cover: '/images/cases/生成家居风格图片 (6).png',
        style: '现代简约',
        area: '65',
        layout: '一室一厅',
        budget: '6-8万',
        duration: '60天',
        desc: '小户型的极致利用，简约而不简单，功能性强。',
        designDesc: '针对小户型特点，采用现代简约设计理念。充分利用每一寸空间，通过定制家具和巧妙的收纳设计，实现空间的最大化利用。色调以白色和浅灰为主，搭配简洁线条的家具，营造简约舒适的都市生活空间。',
        designer: '周设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/BDB2FF/fff?text=周',
        designerTitle: '室内设计师',
        designerExp: 6,
        designerWorks: 72
      },
      8: {
        id: 8,
        title: '北欧混搭风',
        cover: '/images/cases/生成家居风格图片 (7).png',
        style: '北欧',
        area: '110',
        layout: '三室两厅',
        budget: '12-18万',
        duration: '80天',
        desc: '北欧风格融合现代元素，清新自然又不失个性。',
        designDesc: '北欧混搭风格将北欧的简约自然与现代设计元素完美融合。以白色和原木色为基调，加入个性化的色彩点缀和装饰品。注重自然光线的利用和绿植的搭配，营造清新、舒适、充满活力的居住空间。',
        designer: '吴设计师',
        designerAvatar: 'https://via.placeholder.com/200x200/FFC6FF/fff?text=吴',
        designerTitle: '高级室内设计师',
        designerExp: 8,
        designerWorks: 118
      }
    }
  },

  onLoad(options) {
    const id = options.id || 1;
    const caseDetail = this.data.casesData[id] || this.data.casesData[1];
    this.setData({ caseDetail });
  },

  toggleFavorite() {
    this.setData({
      isFavorite: !this.data.isFavorite
    });
    wx.showToast({
      title: this.data.isFavorite ? '收藏成功' : '取消收藏',
      icon: 'success'
    });
  },

  contactDesigner() {
    wx.showModal({
      title: '联系设计师',
      content: '请拨打电话：400-888-8888',
      confirmText: '拨打',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: '4008888888'
          });
        }
      }
    });
  },

  onShareAppMessage() {
    return {
      title: this.data.caseDetail.title,
      path: `/pages/case-detail/case-detail?id=${this.data.caseDetail.id}`
    };
  }
})
