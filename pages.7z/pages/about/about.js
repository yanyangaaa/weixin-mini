Page({
  data: {
    honors: [
      { id: 1, icon: '🏆', title: '中国建筑\n装饰协会\n会员单位' },
      { id: 2, icon: '⭐', title: '家装行业\n诚信企业' },
      { id: 3, icon: '🎖️', title: '质量服务\n信誉AAA级' },
      { id: 4, icon: '💎', title: '绿色环保\n推荐企业' },
      { id: 5, icon: '👨‍🎨', title: '优秀设计\n团队奖' },
      { id: 6, icon: '✨', title: '客户满意度\n五星企业' }
    ],
    stats: [
      { id: 1, number: '10+', label: '行业经验' },
      { id: 2, number: '1W+', label: '服务家庭' },
      { id: 3, number: '50+', label: '设计师' },
      { id: 4, number: '99%', label: '满意度' }
    ],
    contacts: [
      { id: 1, icon: '📞', label: '客服热线', value: '400-888-8888', type: 'phone' },
      { id: 2, icon: '💬', label: '在线客服', value: '点击联系客服', type: 'service' },
      { id: 3, icon: '✉️', label: '企业邮箱', value: 'service@youju.com', type: 'email' },
      { id: 4, icon: '🌐', label: '官方网站', value: 'www.youju.com', type: 'website' }
    ],
    mapInfo: {
      latitude: 34.817795,
      longitude: 114.252093,
      address: '开封市龙亭区五大街湖畔家园C9号楼109-112号商铺内部',
      markers: [{
        id: 1,
        latitude: 34.817795,
        longitude: 114.252093,
        iconPath: '/images/marker.png',
        width: 30,
        height: 30,
        title: '简一整装大家居'
      }]
    }
  },

  onLoad() {
    // 页面加载
  },

  handleContact(e) {
    const { type, value } = e.currentTarget.dataset;
    
    switch(type) {
      case 'phone':
        wx.showModal({
          title: '客服热线',
          content: value,
          confirmText: '拨打电话',
          success: (res) => {
            if (res.confirm) {
              wx.makePhoneCall({
                phoneNumber: value.replace(/-/g, '')
              });
            }
          }
        });
        break;
      case 'service':
        wx.showToast({
          title: '客服功能开发中',
          icon: 'none'
        });
        break;
      case 'email':
        wx.setClipboardData({
          data: value,
          success: () => {
            wx.showToast({
              title: '邮箱已复制',
              icon: 'success'
            });
          }
        });
        break;
      case 'website':
        wx.setClipboardData({
          data: value,
          success: () => {
            wx.showToast({
              title: '网址已复制',
              icon: 'success'
            });
          }
        });
        break;
    }
  }
})
