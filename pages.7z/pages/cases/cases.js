Page({
  data: {
    styles: ['现代简约', '北欧', '新中式', '轻奢', '美式', '日式'],
    currentStyle: '',
    allCases: [
      {
        id: 1,
        title: '现代简约三居室',
        cover: '/images/cases/生成家居风格图片.png',
        style: '现代简约',
        area: '120',
        budget: '15-20万',
        desc: '以简洁明快的设计风格为主调，简洁和实用是现代简约风格的基本特点。',
        designer: '张设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/4ECDC4/fff?text=张',
        views: 1250
      },
      {
        id: 2,
        title: '北欧风清新小窝',
        cover: '/images/cases/生成家居风格图片 (1).png',
        style: '北欧',
        area: '95',
        budget: '10-15万',
        desc: '简约、自然、人性化的设计理念，浅色调为主，营造温馨舒适的家居氛围。',
        designer: '李设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/A8E6CF/fff?text=李',
        views: 980
      },
      {
        id: 3,
        title: '新中式大平层',
        cover: '/images/cases/生成家居风格图片 (2).png',
        style: '新中式',
        area: '150',
        budget: '25-30万',
        desc: '传统中式风格与现代元素完美结合，既有古典韵味又不失现代气息。',
        designer: '王设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/FFD3B6/fff?text=王',
        views: 1560
      },
      {
        id: 4,
        title: '轻奢风雅居',
        cover: '/images/cases/生成家居风格图片 (3).png',
        style: '轻奢',
        area: '180',
        budget: '30-40万',
        desc: '低调奢华，注重细节与品质，展现精致优雅的生活品味。',
        designer: '赵设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/DCEDC1/fff?text=赵',
        views: 2100
      },
      {
        id: 5,
        title: '美式田园风格',
        cover: '/images/cases/生成家居风格图片 (4).png',
        style: '美式',
        area: '140',
        budget: '20-25万',
        desc: '温馨舒适，注重实用性，营造休闲自在的居住环境。',
        designer: '刘设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/FFC8DD/fff?text=刘',
        views: 870
      },
      {
        id: 6,
        title: '日式原木风',
        cover: '/images/cases/生成家居风格图片 (5).png',
        style: '日式',
        area: '85',
        budget: '8-12万',
        desc: '追求简约、自然、禅意的设计理念，大量运用原木材质。',
        designer: '陈设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/CAFFBF/fff?text=陈',
        views: 650
      },
      {
        id: 7,
        title: '现代简约公寓',
        cover: '/images/cases/生成家居风格图片 (6).png',
        style: '现代简约',
        area: '65',
        budget: '6-8万',
        desc: '小户型的极致利用，简约而不简单，功能性强。',
        designer: '周设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/BDB2FF/fff?text=周',
        views: 1320
      },
      {
        id: 8,
        title: '北欧混搭风',
        cover: '/images/cases/生成家居风格图片 (7).png',
        style: '北欧',
        area: '110',
        budget: '12-18万',
        desc: '北欧风格融合现代元素，清新自然又不失个性。',
        designer: '吴设计师',
        designerAvatar: 'https://via.placeholder.com/100x100/FFC6FF/fff?text=吴',
        views: 1450
      }
    ],
    filteredCases: []
  },

  onLoad() {
    this.setData({
      filteredCases: this.data.allCases
    });
  },

  filterByStyle(e) {
    const style = e.currentTarget.dataset.style;
    this.setData({
      currentStyle: style
    });

    if (style === '') {
      this.setData({
        filteredCases: this.data.allCases
      });
    } else {
      const filtered = this.data.allCases.filter(item => item.style === style);
      this.setData({
        filteredCases: filtered
      });
    }
  },

  goToDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/case-detail/case-detail?id=${id}`
    });
  }
})
