Page({
  data: {
    formData: {
      name: '',
      phone: '',
      area: '',
      style: '',
      budget: '',
      address: '',
      datetime: '',
      remark: ''
    },
    styles: ['现代简约', '北欧', '新中式', '轻奢', '美式', '日式', '欧式', '其他'],
    styleIndex: 0,
    budgets: ['5-10万', '10-15万', '15-20万', '20-30万', '30-50万', '50万以上'],
    budgetIndex: 0,
    dateTimeRange: [
      ['今天', '明天', '后天', '本周内', '下周'],
      ['上午9-12点', '下午14-18点', '晚上18-20点']
    ],
    dateTimeIndex: [0, 0],
    depositAmount: 500  // 定金金额
  },

  onLoad() {
    // 页面加载
  },

  onNameInput(e) {
    this.setData({
      'formData.name': e.detail.value
    });
  },

  onPhoneInput(e) {
    this.setData({
      'formData.phone': e.detail.value
    });
  },

  onAreaInput(e) {
    this.setData({
      'formData.area': e.detail.value
    });
  },

  onStyleChange(e) {
    const index = e.detail.value;
    this.setData({
      styleIndex: index,
      'formData.style': this.data.styles[index]
    });
  },

  onBudgetChange(e) {
    const index = e.detail.value;
    this.setData({
      budgetIndex: index,
      'formData.budget': this.data.budgets[index]
    });
  },

  onAddressInput(e) {
    this.setData({
      'formData.address': e.detail.value
    });
  },

  onDateTimeChange(e) {
    const indices = e.detail.value;
    const date = this.data.dateTimeRange[0][indices[0]];
    const time = this.data.dateTimeRange[1][indices[1]];
    this.setData({
      dateTimeIndex: indices,
      'formData.datetime': `${date} ${time}`
    });
  },

  onRemarkInput(e) {
    this.setData({
      'formData.remark': e.detail.value
    });
  },

  validateForm() {
    const { name, phone, area, style } = this.data.formData;

    if (!name || name.trim() === '') {
      wx.showToast({
        title: '请输入您的称呼',
        icon: 'none'
      });
      return false;
    }

    if (!phone || phone.trim() === '') {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none'
      });
      return false;
    }

    const phoneReg = /^1[3-9]\d{9}$/;
    if (!phoneReg.test(phone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      });
      return false;
    }

    if (!area || area.trim() === '') {
      wx.showToast({
        title: '请输入房屋面积',
        icon: 'none'
      });
      return false;
    }

    if (!style || style.trim() === '') {
      wx.showToast({
        title: '请选择装修风格',
        icon: 'none'
      });
      return false;
    }

    return true;
  },

  // 免费预约
  submitForm() {
    if (!this.validateForm()) {
      return;
    }

    wx.showLoading({
      title: '提交中...'
    });

    // 模拟提交请求
    setTimeout(() => {
      wx.hideLoading();
      wx.showModal({
        title: '预约成功',
        content: '感谢您的预约！我们的设计师将在24小时内与您联系，请保持手机畅通。',
        showCancel: false,
        confirmText: '我知道了',
        success: () => {
          // 保存预约记录
          this.saveBookingRecord('free');
          
          // 重置表单
          this.resetForm();

          // 返回首页
          wx.switchTab({
            url: '/pages/index/index'
          });
        }
      });
    }, 1500);
  },

  // 付定金预约
  submitWithDeposit() {
    if (!this.validateForm()) {
      return;
    }

    // 跳转到支付页面
    wx.navigateTo({
      url: `/pages/payment/payment?amount=${this.data.depositAmount}&type=deposit&name=${this.data.formData.name}&phone=${this.data.formData.phone}`
    });
  },

  // 保存预约记录
  saveBookingRecord(type) {
    const record = {
      ...this.data.formData,
      type: type,  // free 或 deposit
      amount: type === 'deposit' ? this.data.depositAmount : 0,
      status: type === 'deposit' ? 'paid' : 'pending',
      createTime: new Date().toLocaleString()
    };

    // 获取现有记录
    let bookingList = wx.getStorageSync('bookingList') || [];
    bookingList.unshift(record);
    
    // 只保留最近20条记录
    if (bookingList.length > 20) {
      bookingList = bookingList.slice(0, 20);
    }

    // 保存到本地
    wx.setStorageSync('bookingList', bookingList);
  },

  // 重置表单
  resetForm() {
    this.setData({
      formData: {
        name: '',
        phone: '',
        area: '',
        style: '',
        budget: '',
        address: '',
        datetime: '',
        remark: ''
      },
      styleIndex: 0,
      budgetIndex: 0,
      dateTimeIndex: [0, 0]
    });
  }
})
