Page({
  data: {
    activeTab: 'all',  // all, booking, payment
    bookingList: [],
    paymentList: [],
    displayList: []
  },

  onLoad() {
    this.loadOrders();
  },

  onShow() {
    this.loadOrders();
  },

  // 加载订单数据
  loadOrders() {
    const bookingList = wx.getStorageSync('bookingList') || [];
    const paymentList = wx.getStorageSync('paymentList') || [];

    this.setData({
      bookingList,
      paymentList
    }, () => {
      this.filterOrders();
    });
  },

  // 切换标签
  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({
      activeTab: tab
    }, () => {
      this.filterOrders();
    });
  },

  // 筛选订单
  filterOrders() {
    const { activeTab, bookingList, paymentList } = this.data;
    let displayList = [];

    switch(activeTab) {
      case 'all':
        // 合并所有订单
        displayList = [
          ...paymentList.map(item => ({ ...item, orderType: 'payment' })),
          ...bookingList.map(item => ({ ...item, orderType: 'booking' }))
        ];
        break;
      case 'booking':
        displayList = bookingList.map(item => ({ ...item, orderType: 'booking' }));
        break;
      case 'payment':
        displayList = paymentList.map(item => ({ ...item, orderType: 'payment' }));
        break;
    }

    this.setData({ displayList });
  },

  // 删除订单
  deleteOrder(e) {
    const { index, type } = e.currentTarget.dataset;

    wx.showModal({
      title: '确认删除',
      content: '确定要删除这条记录吗？',
      success: (res) => {
        if (res.confirm) {
          if (type === 'booking') {
            let bookingList = this.data.bookingList;
            bookingList.splice(index, 1);
            wx.setStorageSync('bookingList', bookingList);
          } else if (type === 'payment') {
            let paymentList = this.data.paymentList;
            paymentList.splice(index, 1);
            wx.setStorageSync('paymentList', paymentList);
          }

          this.loadOrders();
          wx.showToast({
            title: '删除成功',
            icon: 'success'
          });
        }
      }
    });
  },

  // 联系客服
  contactService() {
    wx.makePhoneCall({
      phoneNumber: '4008888888'
    });
  },

  // 再次预约
  bookAgain() {
    wx.switchTab({
      url: '/pages/index/index'
    });
  }
})
